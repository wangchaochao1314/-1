﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ConsoleApp1.Asd1;

using static ConsoleApp1.Vison1;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Process A1 = new Process();
            A1.Asd.AsdName = "主流程";
            Vison a = new Vison("主检测流程");
            A1.Asd.vison= new List<Vison>();
            A1.Asd.vison.Add(a);
            Asd ad1 = new Asd();
            ad1.AsdName = "圆检测";
            ad1.Bol = true;
            Vison a1 = new Vison("直线检测");
            ad1.vison = new List<Vison>();
            ad1.vison.Add(a1);
            A1.Asdlist.Add(ad1);
            A1.Run();
            Console.Read();

        }
    }
}
