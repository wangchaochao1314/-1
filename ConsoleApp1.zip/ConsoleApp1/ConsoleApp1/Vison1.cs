﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApp1
{
    class Vison1
    {

        public  class Vison
        {
            public String StrName;
          
            public Vison(string name)
            {
                StrName = name;
            }
          
           public void Run()
            {
                Console.WriteLine($"流程名{StrName}");
            }

        }
    
    }
}
