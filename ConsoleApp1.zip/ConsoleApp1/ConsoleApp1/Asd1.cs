﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ConsoleApp1.Vison1;

namespace ConsoleApp1
{
    class Asd1
    {
       public class Process
        {
            
            /// <summary>
            /// 子流程列表
            /// </summary>
            public List<Asd> Asdlist= new   List<Asd> ();
            /// <summary>
            /// 子流程实例
            /// </summary>
            public Asd Nextasd;
            /// <summary>
            /// 流程实例
            /// </summary>
            public Asd Asd;
            public void NextAsd()
            {
                foreach (var item in Asdlist)
                {
                    if (item.Bol)
                    {
                        Nextasd = item;


                    }
                    else
                    {
                        Nextasd = item;
                    }
                }
               
            }
            public void NextAsd(int Adress, int Num)
            {
                foreach (var item in Asdlist)
                {
                    if (item.Num == Num)
                    {
                        Nextasd = item;

                    }

                }

            }
            public void Run()
            {
                try
                {
                    foreach (var item in Asd.vison)
                    {
                        item.Run();
                    }
                    NextAsd();
                    Nextasd.Prc = new Process();
                    Nextasd.Prc.Asd = Nextasd;
                    Nextasd.Prc.Run();
                }
                catch
                {

                }

            }


        }
        public struct Asd
        {
            public List<Vison> vison;
            public bool Bol ;
            public int Num;
            public String AsdName;
            public Process Prc;
         
        }
    }
}
